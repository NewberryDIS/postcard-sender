<script>
export let data
</script>
<h1>
    {data.message}
</h1>

<style>
:global(body){
    background: #333 !important;
    color: #ccc !important;
}
</style>
